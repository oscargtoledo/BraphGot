#!/usr/bin/python3
import csv
import networkx as nx
import urllib
import os
import gzip
import re
import math
from telegram.ext import Updater, MessageHandler, Filters
from telegram.ext import CommandHandler
from fuzzywuzzy import fuzz
from fuzzywuzzy import process
from staticmap import CircleMarker, StaticMap, Line
from haversine import haversine


class Node():
    def __init__(self, info):
        self.info = info
        self.left_child = None
        self.right_child = None

    def __repr__(self):
        return self.info['City']


def kdTree(point_list, k, depth=0):
    axis = depth % k
    point_list.sort(key=lambda x: float(x['location'][axis]))
    n = len(point_list)
    if n == 1:
        node = Node(point_list[0])
        return node
    elif n == 2:
        node = Node(point_list[0])
        node.left_child = kdTree(point_list[1:], k, depth + 1)
        return node
    else:
        median = n // 2
        node = Node(point_list[median])
        node.left_child = kdTree(point_list[:median], k, depth + 1)
        node.right_child = kdTree(point_list[median + 1:], k, depth + 1)
        return node


def closeNodes(root, node, distance, depth=0):
    outList = []
    k = 3
    latlon = (float(node['Latitude']), float(node['Longitude']))
    axis = depth % k
    if root is None:
        return outList
    else:
        if float(root.info['location'][axis]) > float(node['location'][axis]):
            outList.extend(closeNodes(root.left_child, node, distance, depth + 1))
            if float(root.info['location'][axis]) - float(node['location'][axis]) < distance * 1.5:
                outList.extend(closeNodes(root.right_child, node, distance, depth + 1))
        elif float(root.info['location'][axis]) < float(node['location'][axis]):
            outList.extend(closeNodes(root.right_child, node, distance, depth + 1))
            if float(node['location'][axis]) - float(root.info['location'][axis]) < distance * 1.5:
                outList.extend(closeNodes(root.left_child, node, distance, depth + 1))
        if haversine((float(root.info['Latitude']), float(root.info['Longitude'])), latlon) <= distance:
            outList.append(root)

        return outList


AppGraph = None
AppTree = None
UserLatLon = None


def generateGraph(bot, update, args):
    print("Graphing with distance " + str(args[0]) + " and population " + str(args[1]))
    if int(args[1]) < 50000:
        bot.send_message(chat_id=update.message.chat_id,
                         text="La població está limitada a 50000 habitants per temes de rendiment")
        return

    if not os.path.isfile('worldcitiespop.csv'):
        print("Downloading")
        bot.send_message(chat_id=update.message.chat_id, text="Necessito obtenir les dades, un moment...")
        urllib.request.urlretrieve("https://raw.githubusercontent.com/jordi-petit/lp-graphbot-2019/master/dades/worldcitiespop.csv.gz",'worldcitiespop.csv.gz')
        print("Downloaded")
        with gzip.open('worldcitiespop.csv.gz', 'rt', encoding='utf8') as f_in:
            with open('worldcitiespop.csv', 'w', encoding='utf8') as f_out:
                for line in f_in:
                    lineL = line.split(',')
                    if lineL[4] != '':
                        del lineL[2]
                        del lineL[2]
                        f_out.write(','.join(map(str, lineL)))
                print("Generated")
                f_in.close()
                f_out.close()

        bot.send_message(chat_id=update.message.chat_id, text="Finalitzada la descarrega")

    bot.send_message(chat_id=update.message.chat_id, text="Començo a generar el graf, un moment...")
    with open('worldcitiespop.csv', 'r', encoding="utf8") as json_file:
        global AppTree
        global AppGraph
        reader = csv.DictReader(json_file)
        AppGraph = nx.Graph()
        other = []
        for city in reader:
            if float(city['Population']) >= int(args[1]):
                new = city
                new['location'] = latLonToXYZ(float(new['Latitude']), float(new['Longitude']))
                other.append(new)
        AppTree = kdTree(other, 3)
        print("Number of nodes: " + str(len(other)))
        for city in other:
            AppGraph.add_node(city['City'] + ", " + city['Country'])
            AppGraph.node[city['City'] + ", " + city['Country']]['info'] = city
            adj = closeNodes(AppTree, city, int(args[0]))
            for acity in adj:
                AppGraph.add_node(acity.info['City'] + ", " + acity.info['Country'])
                AppGraph.node[acity.info['City'] + ", " + acity.info['Country']]['info'] = acity.info
                AppGraph.add_edge(city['City'] + ", " + city['Country'],
                                  acity.info['City'] + ", " + acity.info['Country'])
                AppGraph[city['City'] + ", " + city['Country']][acity.info['City'] + ", " + acity.info['Country']][
                    'distance'] = haversine((float(city['Latitude']), float(city['Longitude'])),
                                            (float(acity.info['Latitude']), float(acity.info['Longitude'])))
    print("Graph generated successfully")
    bot.send_message(chat_id=update.message.chat_id,
                     text="He generat un graf amb els paràmetres:\n 1. Distància <= %i\n 2. Població >= %i" % (
                     int(args[0]), int(args[1])))


def countEdges(bot, update):
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans")
        return
    print(AppGraph.number_of_edges())
    bot.send_message(chat_id=update.message.chat_id, text="El graf té %i arestes" % AppGraph.number_of_edges())


def countNodes(bot, update):
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans")
        return
    print(AppGraph.number_of_nodes())
    bot.send_message(chat_id=update.message.chat_id, text="El graf té %i nodes" % AppGraph.number_of_nodes())


def countCC(bot, update):
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans")
        return
    print(len(list(nx.connected_components(AppGraph))))
    bot.send_message(chat_id=update.message.chat_id,
                     text="El graf té %i components connexes" % len(list(nx.connected_components(AppGraph))))


def latLonToXYZ(lat, lon):
    theta = math.radians(float(lat))
    phi = math.radians(float(lon))
    x = 6371.0 * (math.cos(theta) * math.cos(phi))
    y = 6371.0 * (math.cos(theta) * math.sin(phi))
    z = 6371.0 * (math.sin(theta))
    return x, y, z


def plotPop(bot, update, args):
    args = list(map(float, args))
    if len(args) is 0:
        bot.send_message(chat_id=update.message.chat_id, text="No es pot fer plotpop sense cap argument")
        return
    elif len(args) is 1:
        if UserLatLon is None:
            bot.send_message(chat_id=update.message.chat_id,
                             text="Per a fer un plotpop cal com a mínim pasar una latitud i una longitud o compartir la teva localització")
            return
        else:
            SearchLocation = {'Latitude': UserLatLon[0], 'Longitude': UserLatLon[1],
                              'location': latLonToXYZ(UserLatLon[0], UserLatLon[1])}
    elif len(args) is 3:
        SearchLocation = {'Latitude': args[1], 'Longitude': args[2], 'location': latLonToXYZ(args[1], args[2])}
    else:
        print("Falten arguments")
        return

    global AppTree
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans")
        return
    print("starting")
    file = "temp.png"
    CloseNodes = closeNodes(AppTree, SearchLocation, float(args[0]))
    Map = StaticMap(500, 500)
    Map.add_marker(CircleMarker((SearchLocation['Longitude'], SearchLocation['Latitude']), 'blue', 10))
    print("gotten")
    for node in CloseNodes:
        pos = (float(node.info['Longitude']), float(node.info['Latitude']))
        pop = float(node.info['Population'])
        size = int(pop * 0.000005)
        Map.add_marker(CircleMarker(pos, 'red', size))
    try:
        print("Doing")
        image = Map.render()
        print("Rendered")
        image.save(file)
        print("Saved")
        bot.send_photo(chat_id=update.message.chat_id, photo=open(file, 'rb'))
        os.remove(file)
    except Exception as e:
        print(e)


def plotGraph(bot, update, args):
    args = list(map(float, args))
    if len(args) is 0:
        bot.send_message(chat_id=update.message.chat_id, text="No es pot fer plotpop sense cap argument")
        return
    elif len(args) is 1:
        if UserLatLon is None:
            bot.send_message(chat_id=update.message.chat_id,
                             text="Per a fer un plotpop cal com a mínim pasar una latitud i una longitud o compartir la teva localització")
            return
        else:
            SearchLocation = {'Latitude': UserLatLon[0], 'Longitude': UserLatLon[1],
                              'location': latLonToXYZ(UserLatLon[0], UserLatLon[1])}
    elif len(args) is 3:
        SearchLocation = {'Latitude': args[1], 'Longitude': args[2], 'location': latLonToXYZ(args[1], args[2])}
    else:
        print("Falten arguments")
        return

    global AppTree
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans")
        return
    print("starting")
    file = "temp.png"
    CloseNodes = closeNodes(AppTree, SearchLocation, float(args[0]))
    Map = StaticMap(500, 500)
    print("gotten")
    for node in CloseNodes:
        pos = (float(node.info['Longitude']), float(node.info['Latitude']))
        Map.add_marker(CircleMarker(pos, 'red', 4))
        for edge in AppGraph.adj[node.info['City'] + ", " + node.info['Country']]:
            adjNode = AppGraph.node[edge]
            if haversine((float(SearchLocation['Latitude']), float(SearchLocation['Longitude'])),
                         (float(adjNode['info']['Latitude']), float(adjNode['info']['Longitude']))) <= float(args[0]):
                adjNodePos = (float(adjNode['info']['Longitude']), float(adjNode['info']['Latitude']))
                Map.add_marker(CircleMarker(adjNodePos, 'red', 4))
                Map.add_line(
                    Line(((float(node.info['Longitude']), float(node.info['Latitude'])), adjNodePos), 'blue', 1))
    print("Doing")
    image = Map.render()
    print("Rendered")
    image.save(file)
    print("Saved")
    bot.send_photo(chat_id=update.message.chat_id, photo=open(file, 'rb'))
    os.remove(file)


def pairwise(iterable):
    a = iter(iterable)
    return izip(a, a)


def route(bot, update, args):
    global AppGraph
    if AppGraph is None:
        bot.send_message(chat_id=update.message.chat_id,
                         text="Cal inicialitzar el graf abans d'obtenir rutes")
        return
    try:
        argStr = ""
        for arg in args:
            argStr += str(arg)
        matches = re.findall("\"[a-zA-Z, ]*\"", argStr, re.MULTILINE)
        if len(matches) != 2:
            bot.send_message(chat_id=update.message.chat_id,
                             text="Per a mostrar una ruta cal introduir la sortida i l'arribada")
            return
        param1 = matches[0]
        param2 = matches[1]

        try:
            SOut = process.extract(param1, AppGraph.nodes, scorer=fuzz.token_set_ratio, limit=1)
            Sortida = SOut[0][2]
            if fuzz.token_sort_ratio(param1, Sortida) <= 50:
                bot.send_message(chat_id=update.message.chat_id,
                                 text="La ciutat de sortida més semblant a la demanada és " + str(Sortida))

            AOut = process.extract(param2, AppGraph.nodes, scorer=fuzz.token_set_ratio, limit=1)
            Arribada = AOut[0][2]
            if fuzz.token_sort_ratio(param2, Arribada) <= 50:
                bot.send_message(chat_id=update.message.chat_id,
                                 text="La ciutat d'arribada més semblant a la demanada és " + str(Arribada))

        except Exception:
            bot.send_message(chat_id=update.message.chat_id,
                             text="Ha hagut un error buscant les ciutats, assegura't que siguin correctes")
        try:
            path = nx.dijkstra_path(AppGraph, Sortida, Arribada, 'weight')
        except:
            bot.send_message(chat_id=update.message.chat_id,
                             text="No s'ha trobat camí")
            return
        Map = StaticMap(500, 500)
        for n in path:
            Map.add_marker(CircleMarker(
                (float(AppGraph.node[n]['info']['Longitude']), float(AppGraph.node[n]['info']['Latitude'])), 'red',
                4))
        for n, v in zip(path, path[1:] + [path[0]]):
            if (not v is Sortida) and (not n is Arribada):
                Map.add_marker(CircleMarker(
                    (float(AppGraph.node[v]['info']['Longitude']), float(AppGraph.node[v]['info']['Latitude'])),
                    'red', 4))
                Map.add_line(Line((((
                    float(AppGraph.node[n]['info']['Longitude']), float(AppGraph.node[n]['info']['Latitude']))), ((
                    float(AppGraph.node[v]['info']['Longitude']), float(AppGraph.node[v]['info']['Latitude'])))),
                    'blue', 2))
        file = "temp.png"
        print("Rendering")
        image = Map.render()
        print("Rendered")
        image.save(file)
        print("Saved")
        bot.send_photo(chat_id=update.message.chat_id, photo=open(file, 'rb'))
        os.remove(file)
    except KeyError:
        bot.send_message(chat_id=update.message.chat_id, text="La ciutat de sortida no existeix")
        print("Error")
    except Exception as e:
        bot.send_message(chat_id=update.message.chat_id, text="Ha ocurrit un error")
        print(e)


def start(bot, update):
    bot.send_message(chat_id=update.message.chat_id,
                     text="Hola %s! Pots fer servir /help per obtenir ajuda sobre com funciono" % update.message.chat.first_name)

def author(bot,update):
    bot.send_message(chat_id=update.message.chat_id,
                     text="Autor: Òscar García Toledo\nEmail: oscar.garcia.toledo@est.fib.upc.edu")

def help(bot,update):
    bot.send_message(chat_id=update.message.chat_id,
                     text="Ajuda sobre el funcionament:\n"
                          "Soc un bot que manipula grafs geomètrics sobre poblacions a la Terra!\n"
                          "Les meves capabilitats són:\n"
                          "1. /help: Aquesta comanda.\n"
                          "2. /author: Mostro l'autor d'aquest bot.\n"
                          "3. /graph <distance> <population>: Genero un graf geométric que conté ciutats de <population> o més habitants, i conecto les que es trobin a menys de <distance> quilometres.\n"
                          "4. /nodes: Mostro el nombre de nodes del graf generat.\n"
                          "5. /edges: Mostro el nombre d'arestes del graf generat.\n"
                          "6. /components: Mostro el nombre de components connexes del graf generat.\n"
                          "7. /plotpop <dist> [<lat> <lon>]: Mostro un mapa amb les ciutats a una distància <dist> de <lat>,<lon>. En cas que no introdueixis <lat>,<lon>, necessitare la teva localització.\n"
                          "8. /plotgraph <dist> [<lat> <lon>]: Mostro un mapa amb les ciutats a una distància <dist> de <lat>,<lon> i les arestes que les conecten. En cas que no introdueixis <lat>,<lon>, necessitare la teva localització.\n"
                          "9. /route <src> <dist>: Mostro un mapa amb la millor ruta entre <src> <dist>. Necessito que especifiquis per cada ciutat de la manera \"Nom, codi_pais\".\n")

def where(bot, update, user_data):
    global UserLatLon
    UserLatLon = (update.message.location.latitude, update.message.location.longitude)
    bot.send_message(chat_id=update.message.chat_id,
                     text='Ets a les coordenades %f %f' % (float(UserLatLon[0]), float(UserLatLon[1])))


def init():
    TOKEN = open('token.txt').read().strip()
    updater = Updater(token=TOKEN)
    dispatcher = updater.dispatcher

    dispatcher.add_handler(CommandHandler('start', start))
    dispatcher.add_handler(CommandHandler('help', help))
    dispatcher.add_handler(CommandHandler('nodes', countNodes))
    dispatcher.add_handler(CommandHandler('edges', countEdges))
    dispatcher.add_handler(CommandHandler('components', countCC))
    dispatcher.add_handler(CommandHandler('graph', generateGraph, pass_args=True))
    dispatcher.add_handler(CommandHandler('plotpop', plotPop, pass_args=True))
    dispatcher.add_handler(CommandHandler('plotgraph', plotGraph, pass_args=True))
    dispatcher.add_handler(CommandHandler('route', route, pass_args=True))
    dispatcher.add_handler(MessageHandler(Filters.location, where, pass_user_data=True))
    updater.start_polling()
    print("Started polling")



init()

