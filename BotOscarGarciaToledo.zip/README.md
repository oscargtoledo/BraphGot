﻿# Pràctica Python Curs 2019 LP: GraphBot

Aquest document descriu les funcionalitats del bot GraphBot.
## Arxius
El fixer zip conté:
- **braphgot.py**: Fitxer que conté tot el codi del bot.
- **requirements.txt**: Fitxer que conté totes les dependéncies del bot.
- **README.md**: Aquest document

## Funcions
En aquest apartat s'explicaran breument totes les funcions importants que conté el bot:
- **init()**: Funció encarregada d'inicialitzar el bot. Importa el token i crea els handlers de les comandes.
- **start()**: Funció que presenta el bot a l'usuari, redirigintlo a **help()** en cas de que necessiti ajuda.
- **help()**: Envia un missatge a l'usuari que l'indica com fer servir totes les capabilitats del bot.
- **author()**: Envia un missatge a l'usuari que conté la informació del autor.
- **generateGraph()**:Donada una distància i una població, genera un graf geomètric que té com a nodes ciutats amb població major o igual a la donada i connectades a altres si estan a distància menor o igual a la donada, posant com a pes de cada aresta la distància entre les dues.  
La informació de les ciutats l'extreu d'un fitxer csv. Si aquest fitxer no existeix, el descarrega i el prepara per a l'ús a la funció.  
Per a optimitzar les comprovacions de proximitat, s'empra un KdTree de 3 dimensions, el qual es genera i s'utilitza amb les funcions següents:
  - **kdTree(point_list, k)**: Retorna el node on s'arrela el kdTree de 3 dimensions.  
Donada una point_list, en aquest cas, totes les ciutats disponibles, i una k que indica la dimensió de l'arbre, ordena la llista en funció de la profunditat de l'arbre i la dimensió, per exemple, a profunditat 0 sobre x, profunditat 1 sobre y, i profunditat 2 sobre z, agafa l'element a la meitat de la llista i l'estableix com arrel del subarbre, i recursivament genera el fill esquerre, on queden els que tenen la coordenada sobre la qual es discrimina en el nivell amb valor menor o igual a l'arrel, i el fill dret, amb valor major a l'arrel.
  - **closeNodes(root,node,distance)**: Retorna una llista de ciutats amb distància menor o igual a distance de node.
  Donat un kdTree root, utilitza les propietats d'aquest per a buscar candidats a ciutats properes. Per cada candidat, comprova si la distància real és menor o igual a la demanada, i en cas cert, l'incorpora a la llista.
 - **countEdges()**: Funció handler de la comanda */edges*. 
 Si s'ha inicialitzat el graf geomètric, envia un missatge indicant el nombre d'arestes d'aquest.
 - **countNodes()**: Funció handler de la comanda */nodes*. 
 Si s'ha inicialitzat el graf geomètric, envia un missatge indicant el nombre de nodes d'aquest.
 - **countCC()**: Funció handler de la comanda */components*. 
 Si s'ha inicialitzat el graf geomètric, envia un missatge indicant el nombre de components connexes d'aquest.
 - **plotPop()**: Funció handler de la comanda */plotpop*. 
Si s'ha inicialitzat el graf, donada una distància, i o be un parell latitud longitud, o la localització de l'usuari, s'envia una imatge centrada en el punt de referència  introduït per l'usuari, que mostra en un radi de la distància introduïda, les ciutats properes a la localització, mostrant per cadascuna un punt amb grandària en funció de la població.  
De la mateixa manera que amb la generació del graf, s'utilitza el kdTree generat prèviament per a trobar eficientment les ciutats properes.
- **plotGraph()**: Funció handler de la comanda */plotgraph*. 
Si s'ha inicialitzat el graf, donada una distància, i o be un parell latitud longitud, o la localització de l'usuari, s'envia una imatge centrada en el punt de referència  introduït per l'usuari, que mostra en un radi de la distància introduïda, les ciutats properes a la localització i les seves connexions en funció del graf generat.  
De la mateixa manera que amb la generació del graf i el plotPop, s'utilitza el kdTree generat prèviament per a trobar eficientment les ciutats properes.
- **route()**: Funció handler de la comanda *route*.
Donades dues ciutats amb les seves abreviacions de país corresponents, es troba el millor camí entre elles dos, si n'existeix un.  
Per a trobar el camí, s'utilitza l'algorisme de dijkstra amb pesos a les arestes, que com s'ha mencionat prèviament, són la distància real entre dos ciutats. Aquest s'executa sobre el graf generat prèviament, i envia una imatge a l'usuari que mostra la ruta.

